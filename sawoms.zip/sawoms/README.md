# SAWOMS storefront

Static HTML/CSS/JS + one Vercel serverless fn (Stripe Checkout).

```
sawoms/
├─ index.html  styles.css  app.js
├─ products.json        # catalog (single source of truth, client + server)
├─ assets/              # logo.png, logo-white.png (replace product art with photos later)
├─ api/checkout.js      # POST /api/checkout → Stripe Checkout Session
├─ vercel.json  package.json
```

## Run locally
```bash
npm i -g vercel
vercel dev                 # serves static + /api/checkout
# static only (no checkout): npx serve .
```
Create `.env.local`:
```
STRIPE_SECRET_KEY=sk_test_xxx
```

## Deploy
**Git:** push repo → vercel.com/new → import → add env `STRIPE_SECRET_KEY` (Settings → Environment Variables) → Deploy.
**CLI:** `vercel` (preview) → `vercel env add STRIPE_SECRET_KEY` → `vercel --prod`.

Test card: `4242 4242 4242 4242`, any future date, any CVC.

## Edit
- Price: `products.json` → `price` (GBP, whole pounds). Server uses it; client display reads it.
- Products/colours: `products.json`. Real photos: replace `productSVG()` calls in `app.js` with `<img>` tags.
- Policies / newsletter: placeholders in `app.js` — wire real copy and an email provider.
