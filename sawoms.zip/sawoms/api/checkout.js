// Vercel serverless function: POST /api/checkout
// Prices come from products.json on the server. Client-sent prices are ignored.
// Needs env var: STRIPE_SECRET_KEY  (sk_test_... for test mode)
// Optional: SITE_URL (e.g. https://sawoms.vercel.app) — else derived from request host.

const catalog = require("../products.json");

const MAX_QTY = 20;

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return res.status(500).json({ error: "Checkout not configured (missing STRIPE_SECRET_KEY)." });

  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (!items.length) return res.status(400).json({ error: "Cart empty." });

  const params = new URLSearchParams();
  params.set("mode", "payment");
  params.set("shipping_address_collection[allowed_countries][0]", "GB");
  params.set("shipping_options[0][shipping_rate_data][type]", "fixed_amount");
  params.set("shipping_options[0][shipping_rate_data][display_name]", "Free UK shipping");
  params.set("shipping_options[0][shipping_rate_data][fixed_amount][amount]", "0");
  params.set("shipping_options[0][shipping_rate_data][fixed_amount][currency]", catalog.currency);
  params.set("allow_promotion_codes", "true");

  let i = 0;
  for (const it of items) {
    const p = catalog.products.find(x => x.id === it.id);
    const color = p?.colors.find(c => c.name === it.color);
    const qty = Number.isInteger(it.qty) ? it.qty : 0;
    if (!p || !color || !catalog.sizes.includes(it.size) || qty < 1 || qty > MAX_QTY) {
      return res.status(400).json({ error: "Invalid cart item." });
    }
    const pre = `line_items[${i}]`;
    params.set(`${pre}[quantity]`, String(qty));
    params.set(`${pre}[price_data][currency]`, catalog.currency);
    params.set(`${pre}[price_data][unit_amount]`, String(catalog.price * 100)); // £199 → pence
    params.set(`${pre}[price_data][product_data][name]`, `${p.name} — ${color.name} / ${it.size}`);
    params.set(`${pre}[price_data][product_data][metadata][sku]`, p.id);
    i++;
  }

  const proto = req.headers["x-forwarded-proto"] || "https";
  const base = (process.env.SITE_URL || `${proto}://${req.headers.host}`).replace(/\/$/, "");
  params.set("success_url", `${base}/?checkout=success`);
  params.set("cancel_url", `${base}/?checkout=cancel`);

  try {
    const r = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: params
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data.error?.message || "Stripe error." });
    return res.status(200).json({ url: data.url });
  } catch (e) {
    return res.status(502).json({ error: "Could not reach Stripe." });
  }
};
