/* SAWOMS — app.js (vanilla ES6+) */
(() => {
  "use strict";

  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const CART_KEY = "sawoms.cart.v1";
  const fmt = n => `£${n.toLocaleString("en-GB")}`;

  const state = { data: null, filter: "all", cart: load(), modal: null };

  /* ---------- storage ---------- */
  function load() {
    try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; } catch { return []; }
  }
  function save() {
    try { localStorage.setItem(CART_KEY, JSON.stringify(state.cart)); } catch {}
  }

  /* ---------- placeholder art (original SVG; swap for real photos) ---------- */
  const SHAPES = {
    hoodie: {
      body: "M140 78 Q200 28 260 78 L332 112 L388 338 L336 352 L304 214 L304 402 Q200 420 96 402 L96 214 L64 352 L12 338 L68 112 Z",
      hood: "M140 80 Q200 -6 260 80 Q200 140 140 80Z",
      extra: `<path d="M140 292 L260 292 L276 352 L124 352 Z" fill="rgba(0,0,0,.14)"/>
              <rect x="96" y="388" width="208" height="18" fill="rgba(0,0,0,.18)"/>
              <rect x="12" y="334" width="52" height="18" transform="rotate(-8 12 334)" fill="rgba(0,0,0,.18)"/>
              <rect x="336" y="334" width="52" height="18" transform="rotate(8 388 334)" fill="rgba(0,0,0,.18)"/>`
    },
    tee: {
      body: "M134 60 Q200 108 266 60 L352 104 L318 176 L296 160 L296 392 L104 392 L104 160 L82 176 L48 104 Z",
      hood: "M150 58 Q200 100 250 58 Q200 78 150 58Z",
      extra: ""
    }
  };

  function graphic(kind, ink, view) {
    // ink = contrasting colour for print
    const s = view === "back" ? 1.35 : 1;
    const g = {
      slash: `<path d="M150 190 Q210 120 270 150 Q230 170 215 205 L285 205 Q250 290 150 300 Q205 270 215 235 L150 235Z" fill="${ink}"/>`,
      orbit: `<g fill="none" stroke="${ink}" stroke-width="5"><circle cx="200" cy="230" r="62"/><circle cx="200" cy="230" r="40" stroke-dasharray="4 6"/><ellipse cx="200" cy="230" rx="92" ry="26" transform="rotate(-24 200 230)"/></g><circle cx="200" cy="230" r="9" fill="${ink}"/>`,
      static: `<g fill="${ink}">${Array.from({ length: 70 }, (_, i) => {
        const x = 130 + (i * 37) % 140, y = 170 + ((i * 53) % 120), r = 1.5 + (i % 4);
        return `<circle cx="${x}" cy="${y}" r="${r}"/>`;
      }).join("")}</g>`,
      bolt: `<path d="M215 160 L160 240 L200 240 L180 305 L250 215 L208 215 Z" fill="${ink}"/>`,
      wave: `<g fill="none" stroke="${ink}" stroke-width="5" stroke-linecap="round">${[0, 1, 2, 3, 4].map(i =>
        `<path d="M130 ${185 + i * 20} q17 -22 35 0 t35 0 t35 0 t35 0"/>`).join("")}</g>`,
      grid: `<g stroke="${ink}" stroke-width="2.5">${[0, 1, 2, 3, 4, 5].map(i =>
        `<path d="M${140 + i * 24} 170 V290 M140 ${170 + i * 24} H260"/>`).join("")}</g><rect x="140" y="170" width="120" height="120" fill="none" stroke="${ink}" stroke-width="5"/>`
    }[kind] || "";
    return `<g transform="translate(200 230) scale(${s}) translate(-200 -230)">${g}</g>`;
  }

  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16);
    const c = v => Math.max(0, Math.min(255, v + amt));
    return `rgb(${c(n >> 16)},${c((n >> 8) & 255)},${c(n & 255)})`;
  }
  function luminance(hex) {
    const n = parseInt(hex.slice(1), 16);
    return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
  }

  function productSVG(p, color, view = "front") {
    const shape = SHAPES[p.type];
    const dark = luminance(color.hex) < 0.5;
    const ink = dark ? (p.id === "sw-004" ? "#ff2e93" : "#e8e4da") : "#1b1b1d";
    const id = `${p.id}-${view}-${color.hex.slice(1)}`;
    const detail = view === "detail";
    const vb = detail ? "120 150 160 160" : "0 0 400 440";
    const back = view === "back";
    return `<svg viewBox="${vb}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${p.name} ${color.name} ${view}" preserveAspectRatio="xMidYMid slice">
      <defs>
        <filter id="n-${id}"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="4"/><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 .22 0"/></filter>
        <clipPath id="c-${id}"><path d="${shape.body}"/></clipPath>
      </defs>
      <rect x="-50" y="-50" width="500" height="540" fill="${detail ? shade(color.hex, 0) : "transparent"}"/>
      <path d="${shape.body}" fill="${color.hex}"/>
      <g clip-path="url(#c-${id})">
        <rect width="400" height="440" filter="url(#n-${id})"/>
        <ellipse cx="200" cy="260" rx="150" ry="180" fill="${shade(color.hex, dark ? 14 : -10)}" opacity=".5"/>
      </g>
      ${shape.extra}
      <path d="${shape.hood}" fill="${back ? shade(color.hex, -14) : "#0b0b0c"}" opacity="${back ? 1 : .88}"/>
      ${p.type === "hoodie" && !back ? `<path d="M178 118 v50 M222 118 v50" stroke="${ink}" stroke-width="3" opacity=".7"/>` : ""}
      ${graphic(p.graphic, ink, view)}
      ${!back && !detail ? `<text x="200" y="${p.type === "tee" ? 130 : 150}" text-anchor="middle" font-family="Archivo Black, Impact, sans-serif" font-size="11" letter-spacing="3" fill="${ink}" opacity=".6">SAWOMS</text>` : ""}
    </svg>`;
  }

  /* ---------- data ---------- */
  async function init() {
    $("#year").textContent = new Date().getFullYear();
    try {
      const res = await fetch("/products.json");
      if (!res.ok) throw new Error(res.status);
      state.data = await res.json();
    } catch (e) {
      $("#grid").innerHTML = `<p>Could not load products. Serve over http (e.g. <code>npx serve .</code>), not file://.</p>`;
      return;
    }
    renderHero();
    renderGrid();
    bind();
    renderCart();
    handleReturn();
  }

  const byId = id => state.data.products.find(p => p.id === id);

  /* ---------- hero ---------- */
  function renderHero() {
    const p = byId("sw-001");
    $("#heroArt").innerHTML = productSVG(p, { name: "Acid", hex: "#c6ff00" });
  }

  /* ---------- grid ---------- */
  function renderGrid() {
    const list = state.data.products.filter(p => state.filter === "all" || p.category === state.filter);
    $("#grid").innerHTML = list.map((p, i) => {
      const c = p.colors[0], alt = p.colors[1] || p.colors[0];
      return `<article class="card" style="animation-delay:${i * 40}ms">
        <div class="card__media" data-open="${p.id}" tabindex="0" role="button" aria-label="Quick view ${p.name}">
          ${p.badge ? `<span class="card__tag">${p.badge}</span>` : ""}
          <div class="img img--main">${productSVG(p, c)}</div>
          <div class="img img--alt">${productSVG(p, alt, "back")}</div>
          <span class="card__quick">Quick add</span>
        </div>
        <div class="card__body">
          <div class="card__row"><span class="card__name">${p.name}</span><span class="card__price">${fmt(state.data.price)}</span></div>
          <div class="card__meta"><span>${p.category}</span>
            <span class="dots">${p.colors.map(k => `<i style="background:${k.hex}" title="${k.name}"></i>`).join("")}</span></div>
          <span class="badge">ALL SIZES IN STOCK — £199</span>
        </div>
      </article>`;
    }).join("");
  }

  function setFilter(cat) {
    state.filter = cat;
    $$(".chip").forEach(c => c.classList.toggle("is-active", c.dataset.filter === cat));
    renderGrid();
  }

  /* ---------- product modal ---------- */
  function openProduct(id) {
    const p = byId(id);
    state.modal = { p, color: p.colors[0], size: null, qty: 1, view: "front" };
    $("#pmName").textContent = p.name;
    $("#pmFabric").textContent = p.fabric;
    $("#pmFit").textContent = p.fit;
    $("#pmSizes").innerHTML = state.data.sizes.map(s => `<button type="button" data-size="${s}" aria-pressed="false">${s}</button>`).join("");
    $("#pmColors").innerHTML = p.colors.map((c, i) =>
      `<button type="button" data-ci="${i}" style="background:${c.hex}" aria-label="${c.name}" class="${i === 0 ? "is-active" : ""}"></button>`).join("");
    $("#pmSizeName").textContent = "Select";
    $("#pmErr").hidden = true;
    $("#pmQty").textContent = "1";
    paintModal();
    const dlg = $("#productModal");
    if (!dlg.open) dlg.showModal();
  }

  function paintModal() {
    const { p, color, view } = state.modal;
    $("#pmColorName").textContent = color.name;
    $("#pmMain").innerHTML = productSVG(p, color, view);
    $("#pmThumbs").innerHTML = ["front", "back", "detail"].map(v =>
      `<button type="button" data-view="${v}" class="${v === view ? "is-active" : ""}" aria-label="${v} view">${productSVG(p, color, v)}</button>`).join("");
  }

  /* ---------- cart ---------- */
  const lineKey = l => `${l.id}|${l.color}|${l.size}`;

  function addToCart({ id, color, size, qty }) {
    const key = lineKey({ id, color, size });
    const line = state.cart.find(l => lineKey(l) === key);
    if (line) line.qty = Math.min(20, line.qty + qty);
    else state.cart.push({ id, color, size, qty });
    save(); renderCart();
    const el = $("#cartCount"); el.classList.add("bump"); setTimeout(() => el.classList.remove("bump"), 250);
  }

  function renderCart() {
    const price = state.data ? state.data.price : 199;
    const items = state.cart.reduce((n, l) => n + l.qty, 0);
    $("#cartCount").textContent = items;
    $("#cartItems").textContent = items;
    $("#cartTotal").textContent = fmt(items * price);   // £199 per item, always
    $("#cartEmpty").hidden = items > 0;
    $("#checkoutBtn").disabled = items === 0;
    $("#cartList").innerHTML = state.cart.map(l => {
      const p = byId(l.id); if (!p) return "";
      const c = p.colors.find(k => k.name === l.color) || p.colors[0];
      return `<li class="cart-item" data-key="${lineKey(l)}">
        <div class="cart-item__img">${productSVG(p, c)}</div>
        <div>
          <div class="cart-item__name">${p.name}</div>
          <div class="cart-item__meta">${l.color} · ${l.size}</div>
          <div class="qty"><button data-act="dec" aria-label="Decrease">−</button><output>${l.qty}</output><button data-act="inc" aria-label="Increase">+</button></div>
        </div>
        <div class="cart-item__side"><b>${fmt(l.qty * price)}</b><button class="cart-item__remove" data-act="rm">Remove</button></div>
      </li>`;
    }).join("");
  }

  function openDrawer(open = true) {
    const d = $("#drawer"), o = $("#overlay");
    d.classList.toggle("is-open", open);
    d.setAttribute("aria-hidden", String(!open));
    if (open) { o.hidden = false; requestAnimationFrame(() => o.classList.add("is-on")); }
    else { o.classList.remove("is-on"); setTimeout(() => (o.hidden = true), 300); }
    document.body.style.overflow = open ? "hidden" : "";
  }

  /* ---------- checkout (Stripe via /api/checkout) ---------- */
  async function checkout() {
    const btn = $("#checkoutBtn"), msg = $("#checkoutMsg");
    msg.textContent = ""; btn.disabled = true; btn.textContent = "Redirecting…";
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: state.cart })
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok || !out.url) throw new Error(out.error || `Checkout unavailable (${res.status})`);
      location.href = out.url;
    } catch (e) {
      msg.textContent = e.message;
      btn.disabled = false; btn.textContent = "Checkout";
    }
  }

  function handleReturn() {
    const q = new URLSearchParams(location.search);
    if (q.get("checkout") === "success") {
      state.cart = []; save(); renderCart();
      toast("Order placed. Check your email.");
      history.replaceState({}, "", "/");
    } else if (q.get("checkout") === "cancel") {
      toast("Checkout cancelled. Cart kept.");
      history.replaceState({}, "", "/");
    }
  }

  /* ---------- misc ---------- */
  let toastT;
  function toast(t) {
    const el = $("#toast"); el.textContent = t; el.classList.add("is-on");
    clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove("is-on"), 2600);
  }

  const POLICIES = {
    shipping: ["Shipping", "Free tracked UK delivery on every order. Dispatch in 1–3 working days. (Placeholder text — replace before launch.)"],
    returns: ["Returns", "30-day returns on unworn items with tags. Free UK returns. (Placeholder text — replace before launch.)"],
    privacy: ["Privacy", "We store your cart on your device only. Payments handled by Stripe. (Placeholder text — replace before launch.)"],
    terms: ["Terms", "All prices in GBP and include VAT. Every item is £199. (Placeholder text — replace before launch.)"]
  };

  /* ---------- events ---------- */
  function bind() {
    document.addEventListener("click", e => {
      const t = e.target;
      const nav = t.closest(".nav [data-cat]");
      if (nav) { setFilter(nav.dataset.cat); $("#shop").scrollIntoView(); return; }
      const chip = t.closest(".chip");
      if (chip) return setFilter(chip.dataset.filter);
      const open = t.closest("[data-open]");
      if (open) return openProduct(open.dataset.open);
      if (t.closest("[data-close]")) return t.closest("dialog").close();
      const pol = t.closest("[data-policy]");
      if (pol) {
        const [h, b] = POLICIES[pol.dataset.policy];
        $("#polTitle").textContent = h; $("#polBody").textContent = b;
        return $("#policyModal").showModal();
      }
      if (t.id === "cartToggle" || t.closest("#cartToggle")) return openDrawer(true);
      if (t.closest("#drawerClose") || t.id === "overlay") return openDrawer(false);
      if (t.closest("dialog") === null && t.tagName === "DIALOG") t.close();
    });

    document.addEventListener("keydown", e => {
      if (e.key === "Escape") openDrawer(false);
      if ((e.key === "Enter" || e.key === " ") && e.target.matches?.("[data-open]")) { e.preventDefault(); openProduct(e.target.dataset.open); }
    });

    // Close dialogs on backdrop click
    $$("dialog").forEach(d => d.addEventListener("click", e => { if (e.target === d) d.close(); }));

    // Modal controls
    $("#pmSizes").addEventListener("click", e => {
      const b = e.target.closest("[data-size]"); if (!b) return;
      state.modal.size = b.dataset.size;
      $$("#pmSizes button").forEach(x => { const on = x === b; x.classList.toggle("is-active", on); x.setAttribute("aria-pressed", on); });
      $("#pmSizeName").textContent = b.dataset.size; $("#pmErr").hidden = true;
    });
    $("#pmColors").addEventListener("click", e => {
      const b = e.target.closest("[data-ci]"); if (!b) return;
      state.modal.color = state.modal.p.colors[+b.dataset.ci];
      $$("#pmColors button").forEach(x => x.classList.toggle("is-active", x === b));
      paintModal();
    });
    $("#pmThumbs").addEventListener("click", e => {
      const b = e.target.closest("[data-view]"); if (!b) return;
      state.modal.view = b.dataset.view; paintModal();
    });
    $("#pmMinus").addEventListener("click", () => { state.modal.qty = Math.max(1, state.modal.qty - 1); $("#pmQty").textContent = state.modal.qty; });
    $("#pmPlus").addEventListener("click", () => { state.modal.qty = Math.min(10, state.modal.qty + 1); $("#pmQty").textContent = state.modal.qty; });
    $("#pmAdd").addEventListener("click", () => {
      const m = state.modal;
      if (!m.size) { $("#pmErr").hidden = false; return; }
      addToCart({ id: m.p.id, color: m.color.name, size: m.size, qty: m.qty });
      $("#productModal").close();
      toast(`${m.p.name} (${m.size}) added`);
      openDrawer(true);
    });

    // Cart list actions
    $("#cartList").addEventListener("click", e => {
      const act = e.target.closest("[data-act]"); if (!act) return;
      const key = act.closest(".cart-item").dataset.key;
      const i = state.cart.findIndex(l => lineKey(l) === key); if (i < 0) return;
      if (act.dataset.act === "inc") state.cart[i].qty = Math.min(20, state.cart[i].qty + 1);
      if (act.dataset.act === "dec") state.cart[i].qty -= 1;
      if (act.dataset.act === "rm" || state.cart[i].qty < 1) state.cart.splice(i, 1);
      save(); renderCart();
    });
    $("#checkoutBtn").addEventListener("click", checkout);

    // Cross-tab cart sync
    window.addEventListener("storage", e => { if (e.key === CART_KEY) { state.cart = load(); renderCart(); } });

    // Newsletter (wire to Mailchimp/Klaviyo/etc. — currently local only)
    $("#newsletter").addEventListener("submit", e => {
      e.preventDefault();
      const v = $("#nlEmail").value.trim(), msg = $("#nlMsg");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) { msg.textContent = "Enter a valid email."; return; }
      msg.textContent = "You're in. Watch your inbox.";
      e.target.reset();
    });
  }

  document.addEventListener("DOMContentLoaded", init);
})();
